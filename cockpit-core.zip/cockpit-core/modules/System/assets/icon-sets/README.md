# License

Remix Icon is based on the Apache License Version 2.0 license. Feel free to use these icons in your products and distribute them. We would be very grateful if you mentioned "Remix Icon" in your product info, but it's not required. The only thing we ask is that these icons are not for sale.

https://remixicon.com/