<?php

namespace App\Helper;

class App extends \Lime\Helper {


}