<?php

/**
 * Workaround until SimpleImage supports Avif image type
 */

use claviska\SimpleImage;

class SimpleImageLib extends SimpleImage {

}
